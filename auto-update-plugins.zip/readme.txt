=== Auto Update Plugins ===
Contributors: Geenyous
Donate link: http://www.geenyous.com/
Tags: plugin, update, auto, automatic, automatically
Requires at least: 3.7
Tested up to: 4.1.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin sets Wordpress to automatically download and install plugin updates.

== Description ==

This plugin sets Wordpress to automatically download and install plugin updates.

== Installation ==

1. Upload the `auto-update-plugins` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

This plugin should activate the automatic downloading on plugin updates within Wordpress

== Upgrade Notice ==

0.1 - First version

== Screenshots ==

None

== Changelog ==

= 0.1 =
This is the first version of this plugin.