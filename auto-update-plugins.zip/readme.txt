=== Auto Update Plugins ===
Contributors: Geenyous
Donate link: http://www.geenyous.com/
Tags: plugin, update, auto, automatic
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin sets Wordpress to automatically download and install plugin updates.

== Description ==

This plugin sets Wordpress to automatically download and install plugin updates.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

None

== Upgrade Notice ==

None

== Screenshots ==

None

== Changelog ==

= 0.1 =
This is the first version of this plugin.